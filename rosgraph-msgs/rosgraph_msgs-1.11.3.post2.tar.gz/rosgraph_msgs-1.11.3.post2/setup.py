from setuptools import find_packages, setup
setup(name='rosgraph_msgs', version='1.11.3.post2', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])