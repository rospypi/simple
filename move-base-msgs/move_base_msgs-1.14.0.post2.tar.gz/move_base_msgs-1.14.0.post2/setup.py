from setuptools import find_packages, setup
setup(name='move_base_msgs', version='1.14.0.post2', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])