from setuptools import find_packages, setup
setup(name='std_srvs', version='1.11.2.post0', packages=find_packages(),
      install_requires=['genpy<2000'])