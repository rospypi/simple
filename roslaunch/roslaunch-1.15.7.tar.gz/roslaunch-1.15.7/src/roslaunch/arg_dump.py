# Software License Agreement (BSD License)
#
# Copyright (c) 2013, Willow Garage, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of Willow Garage, Inc. nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Revision $Id$

from __future__ import print_function

"""
Utility module of roslaunch that computes the command-line arguments
for a launch file.
"""

import sys
import roslaunch.xmlloader
from roslaunch.core import RLException
from roslaunch.config import load_config_default

def get_args(roslaunch_files):
    loader = roslaunch.xmlloader.XmlLoader(resolve_anon=False, args_only=True)
    config = load_config_default(roslaunch_files, None, loader=loader, verbose=False, assign_machines=False)
    return loader.root_context.resolve_dict.get('arg_doc', {})

def dump_args(roslaunch_files):
    """
    Print list of args to screen. Will cause system exit if exception
    occurs. This is a subroutine for the roslaunch main handler.

    @param roslaunch_files: list of launch files to load
    @type  roslaunch_files: str
    """

    try:
        args = get_args(roslaunch_files)

        if len(args) == 0:
            print("No arguments.")
        else:
            required_args = [(name, (doc or 'undocumented', default)) for (name, (doc, default)) in args.items() if not default]
            optional_args = [(name, (doc or 'undocumented', default)) for (name, (doc, default)) in args.items() if default]

            if len(required_args) > 0:
                print("Required Arguments:")
                for (name, (doc, _)) in sorted(required_args):
                    print("  %s: %s" % (name, doc))

            if len(optional_args) > 0:
                print("Optional Arguments:")
                for (name, (doc, default)) in sorted(optional_args):
                    print("  %s (default \"%s\"): %s" % (name, default, doc))

    except RLException as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)
