#pragma once

#define ROS_DECLARE_MESSAGE(msg) struct msg;
