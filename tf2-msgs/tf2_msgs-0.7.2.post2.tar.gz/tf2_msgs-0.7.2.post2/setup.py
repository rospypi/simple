from setuptools import find_packages, setup
setup(name='tf2_msgs', version='0.7.2.post2', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])