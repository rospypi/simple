from setuptools import find_packages, setup
setup(name='tf2_msgs', version='0.6.5.post0', packages=find_packages(),
      install_requires=['genpy<2000'])