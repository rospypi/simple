from setuptools import find_packages, setup
setup(name='stereo_msgs', version='1.12.7.post0', packages=find_packages(),
      install_requires=['genpy<2000'])