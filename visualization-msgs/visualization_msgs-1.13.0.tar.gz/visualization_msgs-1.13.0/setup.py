from setuptools import find_packages, setup
setup(name='visualization_msgs', version='1.13.0', packages=find_packages(),
      install_requires=['genpy<2000'])