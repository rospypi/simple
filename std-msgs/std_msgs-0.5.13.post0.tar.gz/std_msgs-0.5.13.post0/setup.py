from setuptools import find_packages, setup
setup(name='std_msgs', version='0.5.13.post0', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])