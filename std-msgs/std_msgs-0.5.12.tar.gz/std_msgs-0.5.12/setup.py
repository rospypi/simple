from setuptools import find_packages, setup
setup(name='std_msgs', version='0.5.12', packages=find_packages(),
      install_requires=['genpy'])