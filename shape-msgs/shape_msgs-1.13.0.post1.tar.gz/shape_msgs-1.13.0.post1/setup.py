from setuptools import find_packages, setup
setup(name='shape_msgs', version='1.13.0.post1', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])