from setuptools import find_packages, setup
setup(name='gazebo_msgs', version='2.5.20.post1', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])